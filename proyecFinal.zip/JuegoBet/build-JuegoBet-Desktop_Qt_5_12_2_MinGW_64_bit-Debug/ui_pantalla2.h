/********************************************************************************
** Form generated from reading UI file 'pantalla2.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PANTALLA2_H
#define UI_PANTALLA2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_pantalla2
{
public:
    QPushButton *pushButton;

    void setupUi(QWidget *pantalla2)
    {
        if (pantalla2->objectName().isEmpty())
            pantalla2->setObjectName(QString::fromUtf8("pantalla2"));
        pantalla2->resize(828, 600);
        pantalla2->setStyleSheet(QString::fromUtf8("background-image: url(:/Sprite/game_objects/pantalla2new.png);"));
        pushButton = new QPushButton(pantalla2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(320, 530, 131, 41));
        pushButton->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 127);\n"
"background-color: rgb(255, 255, 255);"));

        retranslateUi(pantalla2);

        QMetaObject::connectSlotsByName(pantalla2);
    } // setupUi

    void retranslateUi(QWidget *pantalla2)
    {
        pantalla2->setWindowTitle(QApplication::translate("pantalla2", "Form", nullptr));
        pushButton->setText(QApplication::translate("pantalla2", "Continue (>)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class pantalla2: public Ui_pantalla2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PANTALLA2_H
