/********************************************************************************
** Form generated from reading UI file 'pantalla1.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PANTALLA1_H
#define UI_PANTALLA1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_pantalla1
{
public:
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QWidget *pantalla1)
    {
        if (pantalla1->objectName().isEmpty())
            pantalla1->setObjectName(QString::fromUtf8("pantalla1"));
        pantalla1->resize(800, 600);
        pantalla1->setStyleSheet(QString::fromUtf8("background-image: url(:/Sprite/game_objects/R.jpg);"));
        pushButton = new QPushButton(pantalla1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(360, 520, 101, 41));
        pushButton->setStyleSheet(QString::fromUtf8("font: 16pt \"Segoe UI\";\n"
"color: rgb(0, 255, 0);"));
        label = new QLabel(pantalla1);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(310, 30, 191, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("Berlin Sans FB Demi"));
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(9);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("font: 20pt \"Segoe UI\";\n"
"font: 18pt \"MS Shell Dlg 2\";\n"
"font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 20pt \"MS Shell Dlg 2\";\n"
"font: 75 12pt \"Berlin Sans FB Demi\";\n"
"color: rgb(255, 0, 0);"));

        retranslateUi(pantalla1);

        QMetaObject::connectSlotsByName(pantalla1);
    } // setupUi

    void retranslateUi(QWidget *pantalla1)
    {
        pantalla1->setWindowTitle(QApplication::translate("pantalla1", "Form", nullptr));
        pushButton->setText(QApplication::translate("pantalla1", "START", nullptr));
        label->setText(QApplication::translate("pantalla1", "THE MEDIA KILLER", nullptr));
    } // retranslateUi

};

namespace Ui {
    class pantalla1: public Ui_pantalla1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PANTALLA1_H
