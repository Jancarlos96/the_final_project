/********************************************************************************
** Form generated from reading UI file 'play.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLAY_H
#define UI_PLAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Play
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Play)
    {
        if (Play->objectName().isEmpty())
            Play->setObjectName(QString::fromUtf8("Play"));
        Play->resize(800, 600);
        menubar = new QMenuBar(Play);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        Play->setMenuBar(menubar);
        centralwidget = new QWidget(Play);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Play->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Play);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Play->setStatusBar(statusbar);

        retranslateUi(Play);

        QMetaObject::connectSlotsByName(Play);
    } // setupUi

    void retranslateUi(QMainWindow *Play)
    {
        Play->setWindowTitle(QApplication::translate("Play", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Play: public Ui_Play {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLAY_H
