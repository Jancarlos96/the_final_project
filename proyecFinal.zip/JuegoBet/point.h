#ifndef POINT_H
#define POINT_H
struct Point
{
    int x, y;
};

#endif // POINT_H
