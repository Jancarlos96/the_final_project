#include "blockdestruible.h"
#include "block.h"

blockdestruible::blockdestruible()
{
    pixmap = new QPixmap(":/imach/bloquedestruible.png");
    currentsprite = new QPixmap;
}



blockdestruible::~blockdestruible()
{
    delete pixmap;
    delete currentsprite;
}

void blockdestruible::rentpixmap(int x, int y)
{
    *currentsprite = pixmap->copy(x*block_x_size,y*block_y_size,
                                    block_x_size,  block_y_size);
    cargarnuevosprite();
}

void blockdestruible::cargarnuevosprite()
{
    setPixmap(currentsprite->scaled(currentsprite->width(),
                                    currentsprite->height()));
}
