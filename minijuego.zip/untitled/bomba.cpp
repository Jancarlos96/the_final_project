#include "bomba.h"
#include "gameitem.h"
#include <QPainter>


bomba::bomba(QObject *parent): GameItem(parent)
{
//    this->m_heroParent = heroParent;

    texture->load(":/explosion/models/bomb/spriteBomb.png");
    currentTextureX = 0;

    animationTimer = new QTimer(this);
    connect(animationTimer, &QTimer::timeout, this, &bomba::onAnimationTimer);
    animationTimer->start(125);

    QTimer::singleShot(this->timeDestroy, this, &bomba::onDestroyTimer);
}

bomba::~bomba()
{
    delete animationTimer;
}


QRectF bomba::boundingRect() const
{
    return QRectF(- sizeCell.width / 2, - sizeCell.height / 2, sizeCell.width, sizeCell.height);
}

void bomba::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(- sizeCell.width / 2, - sizeCell.height / 2, *texture, currentTextureX, 0, sizeCell.width, sizeCell.height);
    Q_UNUSED(option);
    Q_UNUSED(widget);
}

int bomba::type() const
{
    return BombType;
}

void bomba::onAnimationTimer()
{
    currentTextureX += sizeCell.width;
    if(currentTextureX >= sizeCell.width * 4)
        currentTextureX = 0;

    this->update();
}

void bomba::onDestroyTimer()
{
    emit destroyedBomb(this);
    this->deleteLater();
}
