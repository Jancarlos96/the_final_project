#ifndef BLOCK_H
#define BLOCK_H

#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#define block_x_size 41
#define block_y_size 39

class block: public QObject, public QGraphicsPixmapItem
{
public:
    block();
    ~block();
    void changecurrentpixmap(int x, int y);
    static void generateIndestructibleBlocks();


private:
    QPixmap *pixmap, *currentsprite;
    void cargarnuevosprite();
};

#endif // BLOCK_H
