#ifndef BOMB_H
#define BOMB_H
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
enum Estado{normal,explosion, desaparecer};


class bomb
{
public:
    bomb(int x, int y);
    ~bomb();


private:
    int x;
    int y;

    int ancho;
    int alto;
    int indiceX;

    int tiempo_de_duracion;
    Estado estado;
    QPixmap *pixmap, *currentsprite;

};

#endif // BOMB_H
