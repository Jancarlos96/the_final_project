#ifndef GAME_H
#define GAME_H

#include <QGraphicsScene>
#include <QKeyEvent>
#include "main_character.h"
#include "block.h"
#include "blockdestruible.h"
#include "escenario.h"
#include "block_fondo.h"





class game : public QGraphicsScene //public QObject, public QGraphicsItem
{
    Q_OBJECT
public:
    game();
    ~game();
    void keyPressEvent(QKeyEvent *event);
    int **matriz;
    void generarMatriz();
private:
    main_character *character, *ch;
    block *indestructible[1000], *indes;
    blockdestruible *destruible[1000];
    block_fondo *fondo[1000];
};

#endif // GAME_H
