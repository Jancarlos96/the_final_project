#include "block.h"

block::block()
{
    pixmap = new QPixmap(":/imach/bloqt.png");
    currentsprite = new QPixmap;
}

block::~block()
{
    delete pixmap;
    delete currentsprite;
}



void block::changecurrentpixmap(int x, int y)
{
    *currentsprite = pixmap->copy(x*block_x_size,y*block_y_size,
                                    block_x_size,  block_y_size);
    cargarnuevosprite();
}

void block::cargarnuevosprite()
{
    setPixmap(currentsprite->scaled(currentsprite->width(),
                                    currentsprite->height()));
}

