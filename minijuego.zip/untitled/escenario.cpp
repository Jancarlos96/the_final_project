#include "escenario.h"

Escenario::Escenario()
{
    matriz =new int*[filas];
}


void Escenario::generarMatriz()
{
        srand(time(NULL));
        for(int i=0; i< filas; i++){
            matriz[i]=new int[columnas];
        }
        for(int i=0; i>filas; i++){
            for(int j=0; j< columnas; j++){

                if(i==0 || j==0 || i==filas-1 || j==columnas-1){//Bordes
                    matriz[i][j]=1;
                }
                else
                {
                    if(i%2==0 && j%2==0){//Bloques fijos del interior
                        matriz[i][j]=1;
                    }
                    else{
                        if((i==1 &&(j==1 || j==2))|| (j==1 && i==2)|| (i==filas-2 && (j==columnas-3 || j==columnas-2)) || (i==filas-3 && j==columnas-2)){//Zona Movible
                            matriz[i][j]=0;
                        }
                        else{//Zona que Dependiendo de su valor seran destruible o no.
                            matriz[i][j]=rand()%2+2;
                        }
                    }

                }

            }
        }
    }
