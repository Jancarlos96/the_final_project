#include "block_fondo.h"
#include "block.h"

block_fondo::block_fondo()
{
    pixmap = new QPixmap(":/imach/espada.png");
    currentsprite = new QPixmap;
}

block_fondo::~block_fondo()
{
    delete pixmap;
    delete currentsprite;
}

void block_fondo::rentpixmap(int x, int y)
{
    *currentsprite = pixmap->copy(x*block_x_size,y*block_y_size,
                                    block_x_size,  block_y_size);
    cargarnuevosprite();
}


void block_fondo::cargarnuevosprite()
{
    setPixmap(currentsprite->scaled(currentsprite->width(),
                                    currentsprite->height()));
}
