#ifndef MAIN_CHARACTER_H
#define MAIN_CHARACTER_H
#include <QApplication>
#include <QTimer>
#include <QGraphicsPixmapItem>
#define character_x_size 120
#define character_y_size 108
#define impx 8
#define impy 180


class main_character: public QGraphicsPixmapItem, public QObject
{
public:
    main_character();
    ~main_character();
    void changecurrentpixmap(int x, int y);
    void set_ampliar(double ampliar);
    void moveLeft();
    void moveRight();
    void moveUp();
    void moveDown();
    void posicionar(int x, int y);
    void move_jugador(int type);
    QTimer *getTimer() const;
    void setTimer(QTimer *value);

private:
    double ampliar;
    QPixmap *pixmap, *currentsprite;
    void cargarnuevosprite();
    qreal VelocityY;
    qreal VelocityX;
    qreal aceleracionx, aceleraciony, posx, posy, T, delta;
    void cinematica();
    bool isJumping;
    void jump();
    int cant_sprite, scale;
    void applyGravity();
    QTimer *timer;
};

#endif // MAIN_CHARACTER_H
