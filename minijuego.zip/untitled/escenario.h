#ifndef ESCENARIO_H
#define ESCENARIO_H
#define filas 15
#define columnas 17
#include <ctime>
#include <stdlib.h>


class Escenario
{
public:
    Escenario();
    ~Escenario(){}

    void generarMatriz();

private:
    int **matriz;
};

#endif // ESCENARIO_H
