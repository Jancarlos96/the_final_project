//#include "minijuego.h"

//minijuego::minijuego()
//{

//}

//void minijuego::CalcularVelocidad()
//{

//}

//void minijuego::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
//{
//    painter->setBrush(Qt::cyan);
//    painter->drawElipse(boundingRect());

//}
