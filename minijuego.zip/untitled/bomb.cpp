#include "bomb.h"

bomb::bomb(int x, int y)
{
    pixmap = new QPixmap(":/imach/bomba.png");
    currentsprite = new QPixmap;

    this->x=x;
    this->y=y;
    estado =Estado::normal;
    ancho= 70/3;
    alto=19;

    indiceX=0;
    tiempo_de_duracion=0;

}



