#ifndef BLOCK_FONDO_H
#define BLOCK_FONDO_H
#define block_x_size 40
#define block_y_size 48
#include "block.h"



class block_fondo: public QObject, public QGraphicsPixmapItem // public QGraphicsItem
{
public:
    block_fondo();
    ~block_fondo();
    void rentpixmap(int x, int y);
    static void generateFondoblock();
    //block_fondo object;

private:
    QPixmap *pixmap, *currentsprite;
    void cargarnuevosprite();
};

#endif // BLOCK_FONDO_H
