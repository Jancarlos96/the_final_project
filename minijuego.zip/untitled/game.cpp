#include "game.h"
#include "block.h"
#include "blockdestruible.h"
#include "escenario.h"
#include "block_fondo.h"
#include "main_character.h"

game::game()
{

    //Personaje Principal (°>°)
//    character = new main_character;
//    addItem(character);
//    character->setPos(35,35);
//    character->changecurrentpixmap(0,0);
//    character->set_ampliar(1.2);



    //Mapa:
    //int matriz[filas][columnas];

    //Bloque Solido
//    indestructible = new block;
//    addItem(indestructible);
//    indestructible->setPos(35,0);//100,5)
//    indestructible->changecurrentpixmap(5, 0);

    int tx=35;
    int ty=0;
    for(int i=0; i<19;i++){

        if(i<6 || i>14){
            indestructible[i]= new block;
            addItem(indestructible[i]);
            indestructible[i]->setPos((tx*i),385);
            indestructible[i]->changecurrentpixmap(5,0);
        }

    }



    //Bloque Destruible.
    int th=35;
    for(int i=0; i<19;i++){
        destruible[i]= new blockdestruible;
        addItem(destruible[i]);
        destruible[i]->setPos((th*i),490);
        destruible[i]->rentpixmap(5,0);
    }



    //Bloque de Fondo

    for(int i=0; i<5;i++){

        if((i%2)==0){
            fondo[i]= new block_fondo;
            addItem(fondo[i]);
            fondo[i]->setPos((35*i)+105,(35*i)+140);
            fondo[i]->rentpixmap(5,0);
        }


    }

//    fondo[1]= new block_fondo;
//    addItem(fondo[1]);
//    fondo[1]->setPos(90,90);
//    fondo[1]->rentpixmap(5,0);




//    //Dibujar Matriz:
//        for(int i=0; i<filas; i++){
//            for(int j=0; j< columnas; j++){

//                if(i==0 || j==0 || i==filas-1 || j==columnas-1){//Bordes
//                    matriz[i][j]=1;
//                }
//                else
//                {
//                    if(i%2==0 && j%2==0){//Bloques fijos del interior
//                        matriz[i][j]=1;
//                    }
//                    else{
//                        if((i==1 &&(j==1 || j==2))|| (j==1 && i==2)|| (i==filas-2 && (j==columnas-3 || j==columnas-2)) || (i==filas-3 && j==columnas-2)){//Zona Movible
//                            matriz[i][j]=0;
//                        }
//                        else{//Zona que Dependiendo de su valor seran destruible o no.
//                            matriz[i][j]=rand()%2+2;
//                        }
//                    }

//                }

//            }
//        }





//        for (int i=0; i< filas ; i++){
//            for (int j=0; j<columnas; j++){

//                if(matriz[i][j]==1){
//                    indestructible[i]= new block;
//                    addItem(indestructible[i]);
//                    indestructible[i]->setPos(tx,ty);
//                    indestructible[i]->changecurrentpixmap(5,0);
//                }
//                else{
//                    if(matriz[i][j]==2){
//                        destruible[i]= new blockdestruible;
//                        addItem(destruible[i]);
//                        destruible[i]->setPos(tx,ty);
//                        destruible[i]->rentpixmap(5,0);
//                    }
//                    else{
//                        fondo[i]= new block_fondo;
//                        addItem(fondo[i]);
//                        fondo[i]->setPos(tx,ty);
//                        fondo[i]->rentpixmap(5,0);
//                    }

//                }
//                tx=tx+35;

//            }
//            ty=ty+35;
//            tx=0;
//        }

    //timer = new QTimer();
    //conect(timer, &QTimer::timeout, this &"clase"::"funcion")

    character = new main_character;
    addItem(character);
    character->posicionar(120,120);
    character->changecurrentpixmap(0,0);
    character->set_ampliar(0.5);

//    fondo[1]= new block_fondo;
//    addItem(fondo[1]);
//    fondo[1]->setPos(90,90);
//    fondo[1]->rentpixmap(5,0);



}

game::~game()
{
    delete character;
    delete indestructible[1000];
    delete destruible[1000];
    delete fondo[1000];

}

void game::keyPressEvent(QKeyEvent *event)
{
    if(event->key()==Qt::Key_D){
        character->moveLeft();
    }
    if(event->key()==Qt::Key_A){
        character->moveRight();
    }
    if(event->key()==Qt::Key_W){
        character->moveDown();
    }
    if(event->key()==Qt::Key_S){
        character->moveUp();
    }
}
