//#ifndef MINIJUEGO_H
//#define MINIJUEGO_H
//#include <QGraphicsPixmapItem>
//#include <QGraphicsScene>
//#include <math.h>
//#include <vector>


//class minijuego:  public QObject, public QGraphicsPixmapItem
//{
//    double posx,posy,masa,radio,vx,vy,ang,ax,ay;
//public:
//    minijuego();
//    minijuego(double x,double y, double masa, double radio, double vx, double vy);
//    void CalcularVelocidad();
//    void CalcularPosicion();
//    double getPosx() const;
//    double getMasa() const;
//    double getPosy() const;
//    void SetAngulo(int value);
//    void SetAceleracionx(int value);
//    void SetAceleraciony(int value);
//    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

//private:
//    float px;
//    float py;
//    const float radio;
//    float vx;
//    float vy;
//    float masa;
//    float ax;
//    float ay;
//    //float e;
//};

//#endif // MINIJUEGO_H
