#include "main_character.h"

main_character::main_character()
{
    pixmap = new QPixmap(":/imach/direcciones.png");
    currentsprite = new QPixmap;
}

main_character::~main_character()
{
    delete pixmap;
    delete currentsprite;
}

void main_character::changecurrentpixmap(int x, int y)
{
    *currentsprite = pixmap->copy(x*character_x_size, y*character_y_size,
                                    character_x_size,   character_y_size);
    cargarnuevosprite();
}

void main_character::set_ampliar(double ampliar)
{
    this->ampliar = ampliar;
    cargarnuevosprite();
}

void main_character::cargarnuevosprite()
{
    setPixmap(currentsprite->scaled(currentsprite->width()*ampliar,
                                    currentsprite->height()*ampliar));
}

void main_character::cinematica()
{
    VelocityX += aceleracionx*T*delta;
    VelocityY += aceleraciony*T*delta;
    posx += VelocityX*T*delta;
    posy += VelocityY*T*delta;
    setPos(posx, posy);
}

void main_character::jump()
{
    const qreal jumVelocity = -60;
    VelocityY = jumVelocity;
    isJumping = true;
}

void main_character::applyGravity()
{
    cinematica();
    if((aceleracionx< 0 && VelocityX <=0) || (aceleracionx > 0 && VelocityX >=0)){

        VelocityX =0;
        aceleracionx=0;
    }

    //const qreal gravity =9.8;
    //const qreal maxVelocityY =10;

    //Aplicar Gravedad:
    //velocityY +=gravity;
    //velocityY = qMin(velocityY, maxVelocityY);

    //Actualizar Posicion Vertical:
    //setY(y()+velocity);

    const qreal groundLevel =500;
    if (y()>= groundLevel){
        setY( groundLevel);
        VelocityY=0;
        isJumping=false;
    }
}


QTimer *main_character::getTimer() const
{
    return timer;
}

void main_character::setTimer(QTimer *value)
{
    timer = value;
}



void main_character::moveRight()
{
    // Contador de cuadros de animación
    static int anim_count = 0;
    int current_x = x();
    changecurrentpixmap(0,3);
    setX(current_x - 3);
    // Cambiar la imagen del sprite si se ha movido lo suficiente
    if (x() != current_x) {
        anim_count++;
        int sprite_x = (anim_count / 5) % 3;
        changecurrentpixmap(sprite_x, 3);
    }
}


void main_character::moveLeft()
{
    static int anim_count = 0;
    int current_x = x();
    changecurrentpixmap(0,1);
    setX(current_x + 3);
    //VelocityX-=impx;
    //cinematica();
    if (x() != current_x) {
        anim_count++;
        int sprite_x = (anim_count / 5) % 3;
        changecurrentpixmap(sprite_x, 1);
    }
}

void main_character::moveUp()
{
    static int anim_count = 0;
    int current_y = y();
    changecurrentpixmap(0,3);
    setY(current_y + 3);
    if (y() != current_y) {
        anim_count++;
        int sprite_y = (anim_count / 5) % 3;
        changecurrentpixmap(sprite_y, 2);
    }
}


void main_character::moveDown()
{
    static int anim_count = 0;
    int current_y = y();
    setY(current_y - 3);
    changecurrentpixmap(0, 3);
    if (y() != current_y) {
        anim_count++;
        int sprite_y = (anim_count / 5) % 3;
        changecurrentpixmap(sprite_y, 0);
    }
}

void main_character::posicionar(int x, int y)
{
    setPos(x,y);
    posx=x;
    posy=y;
}

void main_character::move_jugador(int type)
{
    switch (type) {
    case 0:
        aceleracionx=5;
        VelocityX -= impx;
        break;
    case 1:
        break;

    case 2:
        aceleracionx =-5;
        VelocityX += impx;
        break;
    case 3:
        aceleraciony=30;
        VelocityY -= impy;
        if(!isJumping)
            break;
    default:
        break;


    }
}
