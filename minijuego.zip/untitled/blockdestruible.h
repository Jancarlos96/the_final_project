#ifndef BLOCKDESTRUIBLE_H
#define BLOCKDESTRUIBLE_H
#include "block.h"

#define block_x_size 41
#define block_y_size 38




class blockdestruible: public QObject, public QGraphicsPixmapItem
{
public:
    blockdestruible();
    ~blockdestruible();
    void rentpixmap(int x, int y);
    static void generateDestructibleBlocks();
    //void aplicarGravedad();

private:
    QPixmap *pixmap, *currentsprite;
    void cargarnuevosprite();
    // Calcular la nueva posición del objeto en función del tiempo y la gravedad
    qreal dt = 0.1; // Intervalo de tiempo entre actualizaciones
    qreal g = 9.8; // Aceleración debido a la gravedad
};

#endif // BLOCKDESTRUIBLE_H
